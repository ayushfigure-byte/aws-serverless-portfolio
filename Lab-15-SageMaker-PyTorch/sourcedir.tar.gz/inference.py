import os
import json
import torch
import numpy as np

def model_fn(model_dir):
    """Loads the model from the model_dir for inference."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_path = os.path.join(model_dir, "full_model.pt")
    if os.path.exists(model_path):
        model = torch.load(model_path, map_location=device)
    else:
        from train import TemperatureForecastNet
        model = TemperatureForecastNet()
        model.load_state_dict(torch.load(os.path.join(model_dir, "model.pth"), map_location=device))
    model.to(device).eval()
    return model

def input_fn(request_body, request_content_type):
    """Deserializes input JSON into a PyTorch Tensor."""
    if request_content_type == "application/json":
        data = json.loads(request_body)
        # Expected shape: (1, 7, 5) -> 1 sample, 7-day lookback, 5 normalized features
        tensor_data = torch.tensor(data["instances"], dtype=torch.float32)
        return tensor_data
    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_tensor, model):
    """Performs inference on the deserialized tensor."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    with torch.no_grad():
        output = model(input_tensor.to(device))
    return output.cpu().numpy()

def output_fn(prediction, accept):
    """Serializes the prediction result to JSON with operational threshold metadata."""
    if accept == "application/json":
        predicted_tmax = float(prediction[0][0])
        response = {
            "predicted_t_max_fahrenheit": round(predicted_tmax, 2),
            "heat_advisory_trigger": predicted_tmax >= 95.0,
            "severe_heat_warning_trigger": predicted_tmax >= 104.0,
            "model_version": "v1.0-custom-pytorch-lstm"
        }
        return json.dumps(response), accept
    raise ValueError(f"Unsupported accept type: {accept}")
